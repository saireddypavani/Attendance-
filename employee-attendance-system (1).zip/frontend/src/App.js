import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import MyHistory from './pages/MyHistory';
function App(){
  return (
    <BrowserRouter>
      <nav className="topnav">
        <Link to='/'>Dashboard</Link> | <Link to='/history'>My History</Link> | <Link to='/login'>Login</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Dashboard/>} />
        <Route path='/history' element={<MyHistory/>} />
        <Route path='/login' element={<Login/>} />
      </Routes>
    </BrowserRouter>
  );
}
export default App;
