import React, {useEffect,useState} from 'react';
import { API_BASE } from '../config';
export default function MyHistory(){
  const [rows,setRows]=useState([]);
  const token = localStorage.getItem('token');
  useEffect(()=> {
    fetch(API_BASE + '/attendance/my-history', { headers:{ 'Authorization': 'Bearer ' + token } })
    .then(r=>r.json()).then(setRows).catch(()=>setRows([]));
  },[]);
  return (<div className="card"><h2>My Attendance</h2>
    <table><thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Status</th><th>Hours</th></tr></thead>
    <tbody>{rows.map(r=> <tr key={r._id}><td>{r.date}</td><td>{r.checkInTime?new Date(r.checkInTime).toLocaleTimeString() : ''}</td><td>{r.checkOutTime?new Date(r.checkOutTime).toLocaleTimeString():''}</td><td>{r.status}</td><td>{r.totalHours}</td></tr>)}</tbody></table>
  </div>);
}
