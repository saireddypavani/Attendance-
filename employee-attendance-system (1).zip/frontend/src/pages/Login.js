import React, {useState} from 'react';
import { API_BASE } from '../config';
export default function Login(){
  const [email,setEmail]=useState('bob@company.com');
  const [password,setPassword]=useState('Password123');
  const [msg,setMsg]=useState('');
  const submit=async e=>{
    e.preventDefault();
    const res = await fetch(API_BASE + '/auth/login', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if(res.ok){ localStorage.setItem('token', data.token); setMsg('Logged in'); }
    else setMsg(data.message||'Error');
  };
  return (<div className="card">
    <h2>Login</h2>
    <form onSubmit={submit}>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" /><br/>
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" /><br/>
      <button>Login</button>
    </form>
    <p>{msg}</p>
  </div>);
}
