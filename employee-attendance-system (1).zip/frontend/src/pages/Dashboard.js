import React, {useEffect, useState} from 'react';
import { API_BASE } from '../config';
export default function Dashboard(){
  const [data,setData]=useState(null);
  const token = localStorage.getItem('token');
  useEffect(()=>{
    fetch(API_BASE + '/dashboard/employee', { headers: { 'Authorization': 'Bearer ' + token } })
    .then(r=>r.json()).then(setData).catch(()=>setData(null));
  },[]);
  const checkIn = ()=> fetch(API_BASE + '/attendance/checkin', { method:'POST', headers:{ 'Authorization': 'Bearer ' + token }}).then(r=>r.json()).then(setData);
  const checkOut = ()=> fetch(API_BASE + '/attendance/checkout', { method:'POST', headers:{ 'Authorization': 'Bearer ' + token }}).then(r=>r.json()).then(setData);
  return (<div className="card">
    <h2>Employee Dashboard</h2>
    {data ? <>
      <p>Today: {data.todayStatus}</p>
      <p>Total hours this month: {data.totalHours}</p>
    </> : <p>Please login to see data</p>}
    <button onClick={checkIn}>Check In</button> <button onClick={checkOut}>Check Out</button>
  </div>);
}
