# Frontend (React)
This simple frontend uses React Router and fetch to call the backend API.
Update `src/config.js` with the backend URL if needed.
