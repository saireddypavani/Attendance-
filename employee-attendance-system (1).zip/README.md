# Employee Attendance System — Full project

This bundle contains a minimal but working full-stack attendance system:
- backend: Node.js + Express + MongoDB (Mongoose)
- frontend: React (create-react-app style)

Files included:
- backend/: server source, routes, models, seed script
- frontend/: simple React app that talks to the backend

## Quick local run (development)

### Backend
1. Install Node and MongoDB.
2. In `backend/`:
   ```
   npm install
   cp .env.example .env
   # edit .env to set MONGO_URI and JWT_SECRET
   npm run seed    # optional to create sample users
   npm run dev
   ```
3. Backend will run at `http://localhost:5000`

### Frontend
1. In `frontend/`:
   ```
   npm install
   # optionally set REACT_APP_API_BASE to backend API (default http://localhost:5000/api)
   npm start
   ```
2. Frontend will run at `http://localhost:3000`

## API endpoints
See `backend/src/routes/*.js`. Main ones:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/attendance/checkin
- POST /api/attendance/checkout
- GET /api/attendance/my-history
- GET /api/attendance/export (manager)

## Seed users
Email/password: alice@company.com / Password123 (manager)
bob@company.com / Password123 (employee)

---

This package is a starting point: add Redux, calendar UI, charts, CSV export UI, and production setup as needed.
