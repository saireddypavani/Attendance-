const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Attendance = require('../models/Attendance');
const User = require('../models/User');

router.get('/employee', auth, async (req,res)=>{
  try{
    const userId = req.user._id;
    const today = new Date().toISOString().slice(0,10);
    const todayRec = await Attendance.findOne({ userId, date: today });
    const month = today.slice(0,7);
    const agg = await Attendance.aggregate([
      { $match: { userId, date: { $regex: '^' + month } } },
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    const totalHoursAgg = await Attendance.aggregate([
      { $match: { userId, date: { $regex: '^' + month } } },
      { $group: { _id: null, total: { $sum: '$totalHours' } } }
    ]);
    res.json({
      todayStatus: todayRec ? (todayRec.checkInTime ? 'Checked In' : 'Not Checked In') : 'Not Checked In',
      summary: agg,
      totalHours: totalHoursAgg[0]?.total || 0
    });
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

router.get('/manager', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ message: 'Forbidden' });
    const totalEmployees = await User.countDocuments();
    const today = new Date().toISOString().slice(0,10);
    const presentToday = await Attendance.countDocuments({ date: today, checkInTime: { $exists: true } });
    const lateToday = await Attendance.countDocuments({ date: today, status: 'late' });
    res.json({ totalEmployees, presentToday, lateToday });
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

module.exports = router;
