const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Attendance = require('../models/Attendance');
const User = require('../models/User');
const { createObjectCsvWriter } = require('csv-writer');

// Helper to get YYYY-MM-DD
function todayStr(d=new Date()){
  return d.toISOString().slice(0,10);
}

router.post('/checkin', auth, async (req,res)=>{
  try{
    const userId = req.user._id;
    const date = todayStr();
    let att = await Attendance.findOne({ userId, date });
    if(att && att.checkInTime) return res.status(400).json({ message: 'Already checked in' });
    const now = new Date();
    if(!att){
      att = new Attendance({ userId, date, checkInTime: now });
    }else{
      att.checkInTime = now;
    }
    // mark late if after 09:30
    const checkDate = new Date(now);
    const limit = new Date(now);
    limit.setHours(9,30,0,0);
    att.status = (now > limit) ? 'late' : 'present';
    await att.save();
    res.json(att);
  }catch(e){
    console.error(e);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/checkout', auth, async (req,res)=>{
  try{
    const userId = req.user._id;
    const date = todayStr();
    let att = await Attendance.findOne({ userId, date });
    if(!att || !att.checkInTime) return res.status(400).json({ message: 'Not checked in' });
    if(att.checkOutTime) return res.status(400).json({ message: 'Already checked out' });
    att.checkOutTime = new Date();
    const diff = (att.checkOutTime - att.checkInTime) / (1000*60*60); // hours
    att.totalHours = Math.round(diff*100)/100;
    await att.save();
    res.json(att);
  }catch(e){
    console.error(e);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/my-history', auth, async (req,res)=>{
  try{
    const userId = req.user._id;
    const records = await Attendance.find({ userId }).sort({ date: -1 });
    res.json(records);
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

router.get('/my-summary', auth, async (req,res)=>{
  try{
    const userId = req.user._id;
    const month = req.query.month; // YYYY-MM
    const match = month ? { date: { $regex: '^' + month } } : {};
    const agg = await Attendance.aggregate([
      { $match: { userId: req.user._id, ...match } },
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    res.json(agg);
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

// Manager: list all
router.get('/all', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ message: 'Forbidden' });
    const { date } = req.query; // YYYY-MM-DD
    const q = date ? { date } : {};
    const records = await Attendance.find(q).populate('userId','name email employeeId department');
    res.json(records);
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

// export CSV
router.get('/export', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ message: 'Forbidden' });
    const { start, end } = req.query; // YYYY-MM-DD
    const q = {};
    if(start && end) q.date = { $gte: start, $lte: end };
    const records = await Attendance.find(q).populate('userId','name email employeeId department').lean();
    const csvWriter = createObjectCsvWriter({
      path: '/tmp/attendance_export.csv',
      header: [
        {id:'employeeId', title:'Employee ID'},
        {id:'name', title:'Name'},
        {id:'email', title:'Email'},
        {id:'date', title:'Date'},
        {id:'checkInTime', title:'Check In'},
        {id:'checkOutTime', title:'Check Out'},
        {id:'status', title:'Status'},
        {id:'totalHours', title:'Total Hours'}
      ]
    });
    const data = records.map(r=>({
      employeeId: r.userId.employeeId || '',
      name: r.userId.name,
      email: r.userId.email,
      date: r.date,
      checkInTime: r.checkInTime ? new Date(r.checkInTime).toISOString() : '',
      checkOutTime: r.checkOutTime ? new Date(r.checkOutTime).toISOString() : '',
      status: r.status,
      totalHours: r.totalHours || 0
    }));
    await csvWriter.writeRecords(data);
    res.download('/tmp/attendance_export.csv','attendance_export.csv');
  }catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

module.exports = router;
