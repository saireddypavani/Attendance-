// Simple seed script to create users and some attendance data
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const User = require('./models/User');
const Attendance = require('./models/Attendance');
const bcrypt = require('bcryptjs');

async function seed(){
  await mongoose.connect(process.env.MONGO_URI);
  await User.deleteMany({});
  await Attendance.deleteMany({});
  const pw = await bcrypt.hash('Password123',10);
  const manager = await User.create({ name: 'Alice Manager', email:'alice@company.com', password: pw, role:'manager', employeeId:'MGR001', department:'Management' });
  const emp1 = await User.create({ name: 'Bob Employee', email:'bob@company.com', password: pw, role:'employee', employeeId:'EMP001', department:'Engineering' });
  const emp2 = await User.create({ name: 'Carol Employee', email:'carol@company.com', password: pw, role:'employee', employeeId:'EMP002', department:'Design' });
  const today = new Date().toISOString().slice(0,10);
  await Attendance.create({ userId: emp1._id, date: today, checkInTime: new Date(), status: 'present', totalHours: 0 });
  console.log('Seeded!');
  process.exit(0);
}
seed().catch(e=>{ console.error(e); process.exit(1); });
